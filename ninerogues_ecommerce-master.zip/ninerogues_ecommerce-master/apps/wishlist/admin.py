from django.contrib import admin

from .models import WishList

admin.site.register(WishList)